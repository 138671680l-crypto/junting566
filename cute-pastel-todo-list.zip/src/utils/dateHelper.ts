/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Utility functions for date processing, calendar calculations, and Base64 parsing.
 */

// Format date into YYYY-MM-DD
export function formatDate(date: Date): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// Generate the list of YYYY-MM-DD dates to build a 12-week grid (aligned Monday to Sunday)
// Ending on the end of the current week (Sunday) to ensure a solid grid structure.
export function generateHeatmapDays(currentDate: Date = new Date()): Date[] {
  const days: Date[] = [];
  
  // Create a copy of the current date
  const endOfWeek = new Date(currentDate.getTime());
  
  // Find current day of week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
  const currentDay = endOfWeek.getDay();
  
  // We want to align so Sunday is the last day of the week column
  // If today is Monday (1), we need to add 6 days to get to Sunday (7)
  // If today is Sunday (0), we add 0 days.
  const daysToSunday = currentDay === 0 ? 0 : 7 - currentDay;
  endOfWeek.setDate(endOfWeek.getDate() + daysToSunday);
  
  // We want to show 12 full weeks: 12 * 7 = 84 days
  // Start date will be 83 days before this week's Sunday
  const startDate = new Date(endOfWeek.getTime());
  startDate.setDate(endOfWeek.getDate() - 83);
  
  // Walk from startDate to endOfWeek day by day
  const runner = new Date(startDate.getTime());
  for (let i = 0; i < 84; i++) {
    days.push(new Date(runner.getTime()));
    runner.setDate(runner.getDate() + 1);
  }
  
  return days;
}

// Map JavaScript's getDay() to Monday-indexed sequence (0: Monday, ..., 6: Sunday)
export function getMondayIndexedDay(date: Date): number {
  const day = date.getDay();
  return day === 0 ? 6 : day - 1;
}

// Safe Base64 Encoding with support for Unicode (Chinese characters, emojis, etc.)
export function safeEncodeBase64(data: string): string {
  try {
    return btoa(
      encodeURIComponent(data).replace(/%([0-9A-F]{2})/g, (_, p1) => {
        return String.fromCharCode(parseInt(p1, 16));
      })
    );
  } catch (error) {
    console.error('Failed to encode base64:', error);
    return '';
  }
}

// Safe Base64 Decoding with support for Unicode
export function safeDecodeBase64(base64: string): string {
  try {
    return decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join('')
    );
  } catch (error) {
    console.error('Failed to decode base64:', error);
    return '';
  }
}

// Nice phrases for motivational headers
export const CUTE_AFFIRMATIONS = [
  "🌸 一步一步来，你已经超级棒了！",
  "⭐ 今天也是元气满满、努力生活的一天！",
  "🍯 每一个完成的任务, 都是给未来的小礼物~",
  "🐱 喵~ 累了就伸个懒腰，休息一下再继续吧！",
  "🍬 记下计划，然后一口吃掉它们！哼哼~",
  "✨ 努力的光芒, 像星星一样亮晶晶的呢！"
];

export function getRandomDisclaimer() {
  const idx = Math.floor(Math.random() * CUTE_AFFIRMATIONS.length);
  return CUTE_AFFIRMATIONS[idx];
}
