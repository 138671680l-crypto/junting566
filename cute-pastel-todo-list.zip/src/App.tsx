/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, FormEvent, useRef } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'motion/react';
import { 
  Plus, 
  Sparkles, 
  Share2, 
  Smile, 
  Trash2, 
  Heart,
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  Award,
  CheckSquare,
  BookOpen,
  Info,
  Calendar,
  AlertTriangle,
  Flame,
  Check
} from 'lucide-react';

import { TodoItem, CompletionHistory, ShareDataPayload } from './types';
import { formatDate, safeEncodeBase64, safeDecodeBase64 } from './utils/dateHelper';
import Heatmap from './components/Heatmap';
import TodoCard from './components/TodoCard';
import DailyReviewModal from './components/DailyReviewModal';

// 10 Collectible Ceramic Tile Badges
export const CERAMIC_TILES = [
  { symbol: '🌸', name: 'ROSE CHERRY', desc: 'Serene cherry blossoms on a cool spring morning.' },
  { symbol: '🌿', name: 'MINT CLOVER', desc: 'Ultimate fortune and crisp, invigorating mint leaves.' },
  { symbol: '🍋', name: 'CITRUS SUN', desc: 'Bright, zesty lemon pattern filled with positive sun rays.' },
  { symbol: '💜', name: 'AMETHYST STAR', desc: 'Cosmic inspiration carved in deep purple crystals.' },
  { symbol: '🌼', name: 'GOLDEN DAISY', desc: 'Sunny yellow daisy representing simple joys and pure smile.' },
  { symbol: '🍊', name: 'SUNSET GLOW', desc: 'Warm gradient terracotta tiles infused with tangerine energy.' },
  { symbol: '🦋', name: 'AERO ORCHID', desc: 'Gentle porcelain orchid petal symbolizing fresh wisdom.' },
  { symbol: '🥨', name: 'HONEY TWIST', desc: 'Charming golden pretzel weave with a hint of warm honey.' },
  { symbol: '🍭', name: 'BERRY MOSAIC', desc: 'Retro pixelated sweet berry grid of playful tones.' },
  { symbol: '🧁', name: 'CREAM PUFF', desc: 'Soft pastel whipped cream tile that feels like a soft cloud.' }
];

// Aesthetic vintage English supermarket disclaimer quotes
export const PREMIUM_DISCLAIMERS = [
  "🧾 PLAN WITH PURPOSE. SHOP WITH PASSION.",
  "⭐ RECEIPT ID: #7729 - MAKE EACH ACTION COUNT.",
  "🧁 BON VOYAGE! UNLOCK A LOVELY TILE ON EVERY PAYOUT.",
  "🛒 FILL YOUR BASKET WITH FOCUS. HEAL YOUR SOUL.",
  "🥨 TRANSACTION COMPLETED: YOUR FUTURE SELFE WILL THANK YOU.",
  "✨ ALL VALUES ARE NUTRITIOUS FOR THE SOUL."
];

// Audio synthesizer cash register 'Ching' sound using Web Audio API
export function playChingSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const audioCtx = new AudioContextClass();
    
    // Low frequency satisfying 'pop' followed by high metallic frequency
    const osc1 = audioCtx.createOscillator();
    const osc2 = audioCtx.createOscillator();
    const gainNode1 = audioCtx.createGain();
    const gainNode2 = audioCtx.createGain();
    
    osc1.connect(gainNode1);
    gainNode1.connect(audioCtx.destination);
    
    osc2.connect(gainNode2);
    gainNode2.connect(audioCtx.destination);
    
    // Register ding sound
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1); // A5
    
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1760, audioCtx.currentTime); // A6
    osc2.frequency.setValueAtTime(2200, audioCtx.currentTime + 0.08); // C#7
    
    gainNode1.gain.setValueAtTime(0.08, audioCtx.currentTime);
    gainNode1.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
    
    gainNode2.gain.setValueAtTime(0.05, audioCtx.currentTime);
    gainNode2.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
    
    osc1.start();
    osc2.start();
    osc1.stop(audioCtx.currentTime + 0.4);
    osc2.stop(audioCtx.currentTime + 0.55);
  } catch (err) {
    console.warn("AudioContext blocked or failed: ", err);
  }
}

// Default luxury starting items matching supermarket receipt layout
const DEFAULT_TODOS: TodoItem[] = [
  {
    id: 'receipt-1',
    title: '🌸 POUR A CUP OF WARM JASMINE GREEN TEA',
    note: 'Hydrate cleanly to activate cosmic focus vibes.',
    completed: false,
    createdAt: new Date().toISOString(),
    color: 'pink',
  },
  {
    id: 'receipt-2',
    title: '🎯 TRIAL THE COZY "PLAN-DO-CHECK" PROGRESS',
    note: 'Write daily targets here. Review by clicking the calendar paper roll below.',
    completed: false,
    createdAt: new Date().toISOString(),
    color: 'yellow',
  },
  {
    id: 'receipt-3',
    title: '🧁 CHECKOUT ALL ITEMS & CAPTURE TILE BONUSES',
    note: 'Try ticking any task to watch the crimson stamp stamp and tile drops down!',
    completed: true,
    completedAt: formatDate(new Date()),
    createdAt: new Date().toISOString(),
    color: 'green',
    badgeSymbol: '🌸',
    badgeName: 'ROSE CHERRY'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'pomodoro' | 'receipt' | 'calendar'>('pomodoro');
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [history, setHistory] = useState<CompletionHistory>({});
  
  // Create Plan input states
  const [newTitle, setNewTitle] = useState('');
  const [newNote, setNewNote] = useState('');
  const [newColor, setNewColor] = useState('pink');

  // Heatmap selections
  const [selectedDate, setSelectedDate] = useState<string>(formatDate(new Date()));
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [premiumQuote, setPremiumQuote] = useState('');
  
  // Sharing systems
  const [sharedPayload, setSharedPayload] = useState<ShareDataPayload | null>(null);
  const [isSharedMode, setIsSharedMode] = useState(false);
  
  // Soft Notification system
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // POMODORO TIMER SPECIFIC STATES
  const [pomoSession, setPomoSession] = useState<'focus' | 'short' | 'long'>('focus');
  const [pomoTimeLeft, setPomoTimeLeft] = useState<number>(25 * 60);
  const [pomoIsRunning, setPomoIsRunning] = useState<boolean>(false);
  const [pomoFocusCount, setPomoFocusCount] = useState<number>(0);
  const pomoIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Mount logic
  useEffect(() => {
    // Randomized high-end receipt quotation
    const randomIdx = Math.floor(Math.random() * PREMIUM_DISCLAIMERS.length);
    setPremiumQuote(PREMIUM_DISCLAIMERS[randomIdx]);

    // 1. URL parsing for shared list data
    const queryParams = new URLSearchParams(window.location.search);
    const dataParam = queryParams.get('data');

    if (dataParam) {
      try {
        const decodedStr = safeDecodeBase64(dataParam);
        const parsed: ShareDataPayload = JSON.parse(decodedStr);
        if (parsed && Array.isArray(parsed.todos)) {
          setSharedPayload(parsed);
          setIsSharedMode(true);
          setTodos(parsed.todos);
          setHistory(parsed.history || {});
          showToast('🌸 LOADED SHARED PLANS! VIEWING IN PREVIEW CHANNEL.');
          setActiveTab('receipt'); // Open checkout receipt directly on share
          return;
        }
      } catch (e) {
        console.error('Failed to parse shared query data', e);
        showToast('⚠️ ERROR LOADING SHARED LEDGER. RETRIEVING INDIVIDUAL STATION.');
      }
    }

    // 2. Load disk values safely
    const localTodosStr = localStorage.getItem('cute_todo_items');
    const localHistoryStr = localStorage.getItem('cute_todo_history');

    if (localTodosStr) {
      try {
        setTodos(JSON.parse(localTodosStr));
      } catch {
        setTodos(DEFAULT_TODOS);
      }
    } else {
      setTodos(DEFAULT_TODOS);
      localStorage.setItem('cute_todo_items', JSON.stringify(DEFAULT_TODOS));
    }

    if (localHistoryStr) {
      try {
        setHistory(JSON.parse(localHistoryStr));
      } catch {
        setHistory({});
      }
    } else {
      const todayStr = formatDate(new Date());
      const initialHistory: CompletionHistory = {
        [todayStr]: {
          date: todayStr,
          completedTodos: [
            {
              id: 'receipt-3',
              title: '🧁 CHECKOUT ALL ITEMS & CAPTURE TILE BONUSES',
              note: 'Try ticking any task to watch the crimson stamp stamp and tile drops down!',
              completedAt: new Date().toISOString(),
              badgeSymbol: '🌸',
              badgeName: 'ROSE CHERRY'
            }
          ],
          dayNote: 'Tasted the luxury thermal bill app today. The red PAID stamp sound and ceramic design is absolutely breathtaking! Collected my first cherry badge. ☕'
        }
      };
      setHistory(initialHistory);
      localStorage.setItem('cute_todo_history', JSON.stringify(initialHistory));
    }
  }, []);

  // Pomodoro sound notification
  const playPomoNotification = (type: 'finish' | 'click') => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const audioCtx = new AudioContextClass();
      
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'finish') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.12); // E5
        osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.24); // G5
        osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime + 0.36); // C6
        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.75);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.8);
      } else {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.12);
      }
    } catch (e) {
      console.warn("Audio blocked: ", e);
    }
  };

  // Pomodoro ticking effect
  useEffect(() => {
    if (pomoIsRunning) {
      pomoIntervalRef.current = setInterval(() => {
        setPomoTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(pomoIntervalRef.current!);
            setPomoIsRunning(false);
            playPomoNotification('finish');
            
            // Increment Count or switch intervals
            if (pomoSession === 'focus') {
              setPomoFocusCount(c => c + 1);
              showToast('✨ CONGRATS! FOCUS TICKET CHECKED OUT. TAKE A BREAK!');
              setPomoSession('short');
              return 5 * 60;
            } else {
              showToast('⏰ BREAK PERIOD COMPLETED! TIME TO BACK TO BASKET.');
              setPomoSession('focus');
              return 25 * 60;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (pomoIntervalRef.current) clearInterval(pomoIntervalRef.current);
    }

    return () => {
      if (pomoIntervalRef.current) clearInterval(pomoIntervalRef.current);
    };
  }, [pomoIsRunning, pomoSession]);

  const changePomoRoutine = (routine: 'focus' | 'short' | 'long') => {
    playPomoNotification('click');
    setPomoSession(routine);
    setPomoIsRunning(false);
    if (routine === 'focus') setPomoTimeLeft(25 * 60);
    else if (routine === 'short') setPomoTimeLeft(5 * 60);
    else setPomoTimeLeft(15 * 60);
  };

  const togglePomoTimer = () => {
    playPomoNotification('click');
    setPomoIsRunning(!pomoIsRunning);
  };

  const resetPomoTimer = () => {
    playPomoNotification('click');
    setPomoIsRunning(false);
    if (pomoSession === 'focus') setPomoTimeLeft(25 * 60);
    else if (pomoSession === 'short') setPomoTimeLeft(5 * 60);
    else setPomoTimeLeft(15 * 60);
  };

  const formatPomoTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Toast notifier helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4500);
  };

  // Sync back to local db
  const syncToDisk = (updatedTodos: TodoItem[], updatedHistory: CompletionHistory) => {
    if (isSharedMode) return;
    localStorage.setItem('cute_todo_items', JSON.stringify(updatedTodos));
    localStorage.setItem('cute_todo_history', JSON.stringify(updatedHistory));
  };

  // Mark/Toggle complete plan logic with stamp audio register and badge drop!
  const handleToggleComplete = (id: string) => {
    const todayStr = formatDate(new Date());
    let droppedBadgeSymbol = '';
    let droppedBadgeName = '';
    
    const updatedTodos = todos.map((t) => {
      if (t.id === id) {
        const nextCompleted = !t.completed;
        let badgeFields = {};
        if (nextCompleted) {
          // Play the delightful register paid stamp trigger!
          playChingSound();
          
          // Random tile drop out of 10 lovable styles
          const luckyTileIdx = Math.floor(Math.random() * CERAMIC_TILES.length);
          const drop = CERAMIC_TILES[luckyTileIdx];
          droppedBadgeSymbol = drop.symbol;
          droppedBadgeName = drop.name;
          badgeFields = {
            badgeSymbol: drop.symbol,
            badgeName: drop.name
          };
        }
        
        return {
          ...t,
          completed: nextCompleted,
          completedAt: nextCompleted ? todayStr : undefined,
          ...badgeFields
        };
      }
      return t;
    });

    setTodos(updatedTodos);

    // Sync back corresponding entry inside historical records
    const updatedHistory = { ...history };
    const targetCompleted = updatedTodos.filter((t) => t.completed && t.completedAt === todayStr);

    if (!updatedHistory[todayStr]) {
      updatedHistory[todayStr] = {
        date: todayStr,
        completedTodos: [],
      };
    }

    updatedHistory[todayStr].completedTodos = targetCompleted.map((t) => ({
      id: t.id,
      title: t.title,
      note: t.note,
      completedAt: new Date().toISOString(),
      badgeSymbol: t.badgeSymbol,
      badgeName: t.badgeName
    }));

    setHistory(updatedHistory);
    syncToDisk(updatedTodos, updatedHistory);
    
    if (droppedBadgeSymbol) {
      showToast(`🔴 "啪" CHECKOUT SUCCESS! MERCHANDISE PAID. UNLOCKED TILE BONUS: ${droppedBadgeSymbol} ${droppedBadgeName}!`);
    } else {
      showToast('🛒 Product item returned to shopping basket.');
    }
  };

  // Add customized item
  const handleAddTodo = (e: FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newTodo: TodoItem = {
      id: `todo-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: newTitle.trim().toUpperCase(), // Keep words premium
      note: newNote.trim() ? newNote.trim().toUpperCase() : undefined,
      completed: false,
      createdAt: new Date().toISOString(),
      color: newColor,
    };

    const updated = [newTodo, ...todos];
    setTodos(updated);
    syncToDisk(updated, history);

    setNewTitle('');
    setNewNote('');
    showToast('🧾 ITEM REGISTERED TO BASKET RECEIPT SUCCESSFULLY!');
  };

  // Remove plan
  const handleDeleteTodo = (id: string) => {
    const updated = todos.filter((t) => t.id !== id);
    setTodos(updated);
    
    const todayStr = formatDate(new Date());
    const updatedHistory = { ...history };
    if (updatedHistory[todayStr]) {
      updatedHistory[todayStr].completedTodos = updatedHistory[todayStr].completedTodos.filter(
        (t) => t.id !== id
      );
    }

    setHistory(updatedHistory);
    syncToDisk(updated, updatedHistory);
    showToast('🗑️ Item voided from active shopping cart.');
  };

  // Detail edits
  const handleUpdateTodo = (id: string, updates: Partial<TodoItem>) => {
    const formattedUpdates = { ...updates };
    if (updates.title) formattedUpdates.title = updates.title.toUpperCase();
    if (updates.note) formattedUpdates.note = updates.note.toUpperCase();

    const updated = todos.map((t) => (t.id === id ? { ...t, ...formattedUpdates } : t));
    setTodos(updated);

    const todayStr = formatDate(new Date());
    const updatedHistory = { ...history };
    if (updatedHistory[todayStr]) {
      updatedHistory[todayStr].completedTodos = updatedHistory[todayStr].completedTodos.map((c) => {
        if (c.id === id) {
          return {
            ...c,
            title: formattedUpdates.title || c.title,
            note: formattedUpdates.note !== undefined ? formattedUpdates.note : c.note,
          };
        }
        return c;
      });
    }

    setHistory(updatedHistory);
    syncToDisk(updated, updatedHistory);
  };

  // Ordering algorithms
  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const nextList = [...todos];
    const prevItem = nextList[index - 1];
    nextList[index - 1] = nextList[index];
    nextList[index] = prevItem;
    setTodos(nextList);
    syncToDisk(nextList, history);
  };

  const handleMoveDown = (index: number) => {
    if (index === todos.length - 1) return;
    const nextList = [...todos];
    const nextItem = nextList[index + 1];
    nextList[index + 1] = nextList[index];
    nextList[index] = nextItem;
    setTodos(nextList);
    syncToDisk(nextList, history);
  };

  // Reflections logs
  const handleSaveDayNote = (date: string, noteText: string) => {
    const updatedHistory = { ...history };
    if (!updatedHistory[date]) {
      updatedHistory[date] = {
        date,
        completedTodos: [],
      };
    }
    updatedHistory[date].dayNote = noteText;
    setHistory(updatedHistory);
    syncToDisk(todos, updatedHistory);
    setShowReviewModal(false);
    showToast(`📝 REVIEW STATEMENT FOR ${date} SAFELY FILED IN LEDGER.`);
  };

  // Generate shareable base64 structure
  const handleGenerateShareLink = () => {
    const payload: ShareDataPayload = {
      todos,
      history,
    };
    
    const serialized = JSON.stringify(payload);
    const base64Str = safeEncodeBase64(serialized);
    const baseUrl = window.location.origin + window.location.pathname;
    const shareUrl = `${baseUrl}?data=${base64Str}`;

    navigator.clipboard.writeText(shareUrl)
      .then(() => {
        showToast('🔗 STATION COUPLING LINK ATTACHED TO CLIPBOARD! SHARE FREELY.');
      })
      .catch((err) => {
        console.error('Share generation error: ', err);
        showToast('⚠️ COPY TRIPPED. MANUALLY ARCHIVE CORRESPONDING URL.');
      });
  };

  // Import shared data completely
  const handleCloneSharedData = () => {
    if (window.confirm('⚠️ WARN: OVERWRITE LOCAL DATABASE WITH THIS PARSED COUPLING PLAN? INCOMING RECORDS WILL ASSUME OWNERSHIP.')) {
      localStorage.setItem('cute_todo_items', JSON.stringify(todos));
      localStorage.setItem('cute_todo_history', JSON.stringify(history));
      setIsSharedMode(false);
      setSharedPayload(null);
      window.history.replaceState({}, document.title, window.location.pathname);
      showToast('🌸 TRANSACTION GRANTED! COUPLING RESTORED INDEPENDENTLY.');
    }
  };

  // Merge datasets elegantly
  const handleMergeSharedData = () => {
    const localTodosStr = localStorage.getItem('cute_todo_items');
    const localHistoryStr = localStorage.getItem('cute_todo_history');
    
    let localTodos: TodoItem[] = [];
    let localHistory: CompletionHistory = {};
    
    if (localTodosStr) {
      try {
        localTodos = JSON.parse(localTodosStr);
      } catch (e) {
        console.error(e);
      }
    } else {
      localTodos = DEFAULT_TODOS;
    }
    
    if (localHistoryStr) {
      try {
        localHistory = JSON.parse(localHistoryStr);
      } catch (e) {
        console.error(e);
      }
    }

    if (window.confirm('CONFIRM CLONING AND COMBINING SHARED ITEMS TO PREVENT DATA LOSS?')) {
      const localIds = new Set(localTodos.map(t => t.id));
      
      const freshSharedTodos = todos.map(t => {
        if (localIds.has(t.id)) {
          return {
            ...t,
            id: `merged-${t.id}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            title: `${t.title} 👥`
          };
        }
        return t;
      });

      const mergedTodos = [...localTodos, ...freshSharedTodos];
      const mergedHistory: CompletionHistory = { ...localHistory };

      Object.keys(history).forEach((dateKey) => {
        const record = history[dateKey];
        if (!record) return;

        if (mergedHistory[dateKey]) {
          const localNote = mergedHistory[dateKey].dayNote?.trim() || '';
          const sharedNote = record.dayNote?.trim() || '';
          let mergedNote = localNote;
          if (sharedNote && sharedNote !== localNote) {
            mergedNote = localNote ? `${localNote}\n\n👥 MERGED STATEMENT:\n${sharedNote}` : sharedNote;
          }

          const existingCompletedIds = new Set(mergedHistory[dateKey].completedTodos.map(t => t.id));
          const newCompleted = record.completedTodos.map(t => {
            if (existingCompletedIds.has(t.id)) {
              return {
                ...t,
                id: `merged-${t.id}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                title: `${t.title} 👥`
              };
            }
            return t;
          });

          mergedHistory[dateKey] = {
            date: dateKey,
            completedTodos: [...mergedHistory[dateKey].completedTodos, ...newCompleted],
            dayNote: mergedNote
          };
        } else {
          mergedHistory[dateKey] = record;
        }
      });

      setTodos(mergedTodos);
      setHistory(mergedHistory);

      localStorage.setItem('cute_todo_items', JSON.stringify(mergedTodos));
      localStorage.setItem('cute_todo_history', JSON.stringify(mergedHistory));
      
      setIsSharedMode(false);
      setSharedPayload(null);
      window.history.replaceState({}, document.title, window.location.pathname);
      showToast('🌸 MERGING COMPLETE! CO-COUPLED PLANS ARCHIVED INTO LOCAL BASKET.');
    }
  };

  const handleReturnToUserDashboard = () => {
    setIsSharedMode(false);
    setSharedPayload(null);
    window.history.replaceState({}, document.title, window.location.pathname);
    
    const localTodosStr = localStorage.getItem('cute_todo_items');
    const localHistoryStr = localStorage.getItem('cute_todo_history');
    if (localTodosStr) {
      setTodos(JSON.parse(localTodosStr));
    }
    if (localHistoryStr) {
      setHistory(JSON.parse(localHistoryStr));
    } else {
      setHistory({});
    }
    showToast('✨ RETURNED SUCCESSFULLY TO PRIVATE BILL WORKSTATION.');
  };

  // Full reset option
  const handleResetAll = () => {
    if (window.confirm('💥 CLEAR EVERY REGISTERED ITEM AND STAT HISTORY RESTORING FACTORY LABELS?')) {
      localStorage.removeItem('cute_todo_items');
      localStorage.removeItem('cute_todo_history');
      setTodos(DEFAULT_TODOS);
      setHistory({});
      showToast('🌸 RE-ZEROED STATS. UNPACKING EMPTY BASKET!');
    }
  };

  const todayStr = formatDate(new Date());
  const todayCompletionsCount = todos.filter((t) => t.completed).length;
  const activeCount = todos.filter((t) => !t.completed).length;

  // Let's check if all is complete for the shopping satisfaction card
  const isEverythingChecked = todos.length > 0 && todos.every((t) => t.completed);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFE29F] via-[#FFDEE9] to-[#E0F2FE] py-10 px-4 sm:px-6 md:px-8 flex flex-col items-center justify-center selection:bg-rose-100 font-mono">
      
      {/* Dynamic Toast Notification bubble */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4 pointer-events-none"
          >
            <div className="bg-slate-900 text-white border-2 border-slate-700 px-4 py-3 rounded-xl shadow-2xl flex items-center justify-center text-center gap-2 pointer-events-auto font-mono text-xs font-bold uppercase">
              <span className="text-amber-300">★</span>
              <span>{toastMessage}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="w-full max-w-4xl bg-white/95 rounded-[2rem] shadow-2xl border-4 border-slate-800 p-5 sm:p-7 md:p-9 space-y-6 overflow-visible">
        
        {/* Connection Bar for Shared Data Payloads */}
        <AnimatePresence>
          {isSharedMode && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-amber-50 p-4 rounded-2xl border-2 border-dashed border-amber-300 mb-2 flex flex-col md:flex-row items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-100 text-amber-800 rounded-xl border border-amber-200 shrink-0">
                  <Info size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-amber-900 uppercase">CO-PLANNING DATA INFLOW DIRECTIVE DETECTED!</h4>
                  <p className="text-[10px] text-amber-800 font-bold leading-normal">You are exploring a shared ledger. Merge with your local basket, clone overwrite, or return.</p>
                </div>
              </div>
              <div className="flex flex-wrap shrink-0 items-center gap-2 w-full md:w-auto justify-end">
                <button
                  onClick={handleMergeSharedData}
                  className="px-3 py-1.5 bg-[#FFCC33] hover:bg-[#FFCC33]/90 text-white rounded text-[10px] font-black shadow transition-all cursor-pointer"
                >
                  👥 MERGE DATA
                </button>
                <button
                  onClick={handleCloneSharedData}
                  className="px-3 py-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded text-[10px] font-black shadow transition-all cursor-pointer"
                >
                  📥 CLONE OVERWRITE
                </button>
                <button
                  onClick={handleReturnToUserDashboard}
                  className="px-3 py-1.5 bg-white text-slate-700 rounded text-[10px] font-black border border-slate-300 hover:border-slate-800 transition-all cursor-pointer"
                >
                  RETURN TO PRIVATE
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Dynamic Supermarket Brand Header */}
        <header className="border-b-4 border-dashed border-slate-800 pb-6 flex flex-col md:flex-row justify-between items-center md:items-end gap-6">
          <div className="space-y-1.5 text-center md:text-left">
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-800 leading-none">
              AESTHETIC STATION®
            </h1>
            <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">
              {premiumQuote}
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            <button
              onClick={handleGenerateShareLink}
              className="bg-white hover:bg-slate-50 border-2 border-slate-800 px-4 py-2.5 rounded-xl text-slate-800 font-black text-[10px] shadow transition-all scale-100 hover:scale-[1.03] active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <Share2 size={12} />
              SHARE LINK
            </button>
            
            <button
              onClick={() => {
                const randomIdx = Math.floor(Math.random() * PREMIUM_DISCLAIMERS.length);
                setPremiumQuote(PREMIUM_DISCLAIMERS[randomIdx]);
                showToast("QUOTE UPDATED!");
              }}
              className="p-2 border-2 border-slate-800 hover:bg-slate-50 rounded-xl transition-all cursor-pointer"
              title="Rotate Quote"
            >
              <Smile size={14} />
            </button>

            {!isSharedMode && (
              <button
                onClick={handleResetAll}
                className="p-2 border-2 border-rose-500 hover:bg-rose-50 text-rose-600 rounded-xl transition-all cursor-pointer"
                title="Wipe database completely"
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>
        </header>

        {/* Switching Tabs Navigation */}
        <nav className="flex border-4 border-slate-800 rounded-2xl overflow-hidden text-xs font-black divide-x-4 divide-slate-800 bg-slate-50">
          <button
            onClick={() => setActiveTab('pomodoro')}
            className={`flex-1 py-3 text-center transition-all cursor-pointer ${
              activeTab === 'pomodoro' 
                ? 'bg-amber-300 text-slate-900 font-bold' 
                : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            ⏱️ 1. POMODORO TIMER
          </button>
          
          <button
            onClick={() => setActiveTab('receipt')}
            className={`flex-1 py-3 text-center transition-all cursor-pointer ${
              activeTab === 'receipt' 
                ? 'bg-[#FF7EB3] text-white font-bold' 
                : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            🧾 2. DAILY RECEIPT BASKET ({todos.length})
          </button>
          
          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex-1 py-3 text-center transition-all cursor-pointer ${
              activeTab === 'calendar' 
                ? 'bg-sky-400 text-white font-bold' 
                : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            📅 3. THERMAL CALENDAR GRID
          </button>
        </nav>

        {/* Dynamic Display Panel Container */}
        <section className="bg-slate-50/50 p-4 sm:p-6 rounded-2xl border-2 border-slate-200">
          
          {/* TAB 1: POMODORO TIMER (FIRST POINT OF ENTRY) */}
          {activeTab === 'pomodoro' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-md mx-auto text-center py-6 px-4 border-4 border-double border-slate-800 bg-white rounded-3xl relative overflow-hidden shadow-lg"
            >
              {/* Receipt vertical stripes */}
              <div className="absolute top-0 left-4 w-1.5 h-full bg-slate-100 pointer-events-none" />
              <div className="absolute top-0 right-4 w-1.5 h-full bg-slate-100 pointer-events-none" />

              <div className="space-y-4 relative z-10">
                <span className="text-[10px] font-extrabold tracking-widest text-[#FF7EB3] uppercase border border-[#FF7EB3] px-2.5 py-1 rounded bg-pink-50">
                  STATION FOCUS CORE
                </span>
                
                <h3 className="text-lg font-black text-slate-800">CASHIER CONCENTRATION MODULE</h3>
                <p className="text-[10px] text-slate-400 uppercase leading-snug font-bold">
                  Receipt #003 — Track focus durations before shopping checkout
                </p>

                {/* Sub routines bar */}
                <div className="flex justify-center gap-1.5 text-[9px] font-black border-2 border-slate-800 p-1.5 rounded-xl bg-slate-50 max-w-sm mx-auto">
                  <button
                    onClick={() => changePomoRoutine('focus')}
                    className={`flex-1 py-1.5 rounded uppercase ${pomoSession === 'focus' ? 'bg-slate-800 text-white' : 'hover:bg-slate-200 text-slate-600'}`}
                  >
                    FOCUS (25m)
                  </button>
                  <button
                    onClick={() => changePomoRoutine('short')}
                    className={`flex-1 py-1.5 rounded uppercase ${pomoSession === 'short' ? 'bg-slate-800 text-white' : 'hover:bg-slate-200 text-slate-600'}`}
                  >
                    SHORT BREAK (5m)
                  </button>
                  <button
                    onClick={() => changePomoRoutine('long')}
                    className={`flex-1 py-1.5 rounded uppercase ${pomoSession === 'long' ? 'bg-slate-800 text-white' : 'hover:bg-slate-200 text-slate-600'}`}
                  >
                    LONG BREAK (15m)
                  </button>
                </div>

                {/* Big circular ticket timer */}
                <div className="my-8 relative flex items-center justify-center">
                  <svg className="w-48 h-48 transform -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="84"
                      stroke="#F1F5F9"
                      strokeWidth="10"
                      fill="transparent"
                    />
                    <circle
                      cx="96"
                      cy="96"
                      r="84"
                      stroke={pomoSession === 'focus' ? '#FF7EB3' : '#38BDF8'}
                      strokeWidth="10"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 84}
                      strokeDashoffset={(1 - pomoTimeLeft / (pomoSession === 'focus' ? 25 * 60 : pomoSession === 'short' ? 5 * 60 : 15 * 60)) * (2 * Math.PI * 84)}
                      className="transition-all duration-300"
                    />
                  </svg>
                  
                  {/* Central Text */}
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="text-4xl font-extrabold text-slate-800 tracking-tighter">
                      {formatPomoTime(pomoTimeLeft)}
                    </span>
                    <span className="text-[9px] font-black tracking-widest text-[#FF7EB3] uppercase mt-1 animate-pulse">
                      {pomoIsRunning ? "TICKING..." : "PAUSED"}
                    </span>
                  </div>
                </div>

                {/* Timer Controls */}
                <div className="flex justify-center items-center gap-3">
                  <button
                    onClick={togglePomoTimer}
                    className="flex items-center gap-1.5 px-6 py-2.5 bg-slate-800 text-white text-[11px] font-black rounded-xl hover:bg-slate-700 transition-all border-b-4 border-slate-950 active:border-b-0 cursor-pointer"
                  >
                    {pomoIsRunning ? <Pause size={12} /> : <Play size={12} />}
                    {pomoIsRunning ? "PAUSE COUNTER" : "START STATION"}
                  </button>
                  
                  <button
                    onClick={resetPomoTimer}
                    className="p-2.5 border-2 border-slate-300 hover:border-slate-800 rounded-xl text-slate-500 hover:text-slate-800 cursor-pointer"
                    title="Reload Timer"
                  >
                    <RotateCcw size={14} />
                  </button>
                </div>

                {/* Focus summary voucher footer */}
                <div className="pt-4 mt-2 border-t border-dashed border-slate-300 text-[10px] text-slate-400 font-extrabold flex justify-between items-center font-mono">
                  <span>STATION OPERATOR: LQI</span>
                  <span className="text-[#FFCC33]">TOTAL CLEARED: {pomoFocusCount} FOCUS CYCLE</span>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 2: RECEIPT SHOPPING TODO LIST */}
          {activeTab === 'receipt' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                
                {/* Form Inputs & SORTS on left (3 columns on md) */}
                <div className="md:col-span-3 space-y-6">
                  
                  {/* Input form styled like a barcode scanner ledger */}
                  {!isSharedMode && (
                    <form onSubmit={handleAddTodo} className="bg-white p-5 rounded-2xl border-2 border-slate-800 space-y-4 shadow-sm font-mono">
                      <div className="flex items-center gap-2 pb-2 border-b border-dashed border-slate-300">
                        <div className="h-2.5 w-2.5 rounded-full bg-[#FF7EB3]" />
                        <h3 className="font-mono font-extrabold text-[10px] text-slate-700 uppercase tracking-widest">
                          SCAN NEW ITEM TO BASKET
                        </h3>
                      </div>

                      {/* Main Title Input */}
                      <div className="relative">
                        <input
                          type="text"
                          required
                          value={newTitle}
                          onChange={(e) => setNewTitle(e.target.value)}
                          placeholder="ENTER MERCHANDISE TITLE (e.g. CLEAN UP STUDY DESK)..."
                          className="w-full bg-[#FFF9FA] border-2 border-dashed border-slate-300 rounded-xl px-4 py-3.5 text-xs font-bold text-slate-800 placeholder:text-slate-400 shadow-sm outline-none focus:border-slate-800 pr-12 uppercase"
                        />
                        <button
                          type="submit"
                          className="absolute right-2 top-2 h-9 w-9 bg-slate-800 text-white rounded-lg flex items-center justify-center text-lg font-black shadow-sm hover:bg-slate-700 active:scale-95 transition-all cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      {/* Note specification details */}
                      <textarea
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        placeholder="SPECIFICATION MEMO (OPTIONAL CHECKOUT ASSURANCE DETAILS)..."
                        className="w-full px-4 py-2.5 bg-[#FFF9FA] rounded-xl border border-dashed border-slate-300 focus:border-slate-800 outline-none text-[10px] leading-relaxed placeholder:text-slate-400 h-14 resize-none uppercase font-bold"
                      />

                      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                        <div className="flex items-center gap-2 text-[9px] font-bold">
                          <span className="text-slate-400">CARD BORDER:</span>
                          <div className="flex items-center gap-1 font-bold">
                            {['pink', 'yellow', 'green', 'purple', 'blue'].map((colorId) => {
                              const borderStyle: { [key: string]: string } = {
                                pink: 'bg-pink-50 border-pink-300',
                                yellow: 'bg-yellow-50 border-yellow-300',
                                green: 'bg-emerald-50 border-emerald-300',
                                purple: 'bg-purple-50 border-purple-300',
                                blue: 'bg-sky-50 border-sky-300',
                              };
                              return (
                                <button
                                  type="button"
                                  key={colorId}
                                  onClick={() => setNewColor(colorId)}
                                  className={`h-4.5 w-4.5 rounded-full border-2 cursor-pointer transition-all ${borderStyle[colorId]} ${
                                    newColor === colorId ? 'ring-2 ring-slate-800 scale-125' : 'hover:scale-110'
                                  }`}
                                />
                              );
                            })}
                          </div>
                        </div>

                        <span className="text-[9px] text-slate-300 font-extrabold uppercase">
                          POS-NINE STAMP READY
                        </span>
                      </div>
                    </form>
                  )}

                  {/* Complete list container */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between px-1">
                      <h3 className="font-mono font-extrabold text-xs text-slate-700 uppercase flex items-center gap-1.5">
                        <CheckSquare size={14} className="text-[#FF7EB3]" />
                        SHOPPING BILL: BASKET LEDGER ({todos.length})
                      </h3>
                      
                      {/* Count summary indicators */}
                      <div className="text-[9px] font-bold text-slate-500 bg-white border border-slate-200 p-1 px-2.5 rounded-lg">
                        UNPAID: <span className="text-slate-900 font-extrabold">{activeCount}</span> | PAID stamp:{' '}
                        <span className="text-rose-600 font-extrabold">{todayCompletionsCount}</span>
                      </div>
                    </div>

                    {/* Satisfying checkout block if empty or all complete */}
                    {isEverythingChecked && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-yellow-50 border-4 border-double border-yellow-400 p-6 rounded-3xl text-center space-y-3 shadow-md font-mono"
                      >
                        <div className="text-4xl block animate-bounce">🛒🧾★</div>
                        <h4 className="text-xs font-black text-amber-800 tracking-wider">★ ALL TASKS COMPLETE ★</h4>
                        <p className="text-[10px] text-amber-700 max-w-md mx-auto leading-relaxed font-bold uppercase">
                          "YOUR SHOPPING CART HAS BEEN FULLY CHECKED OUT. EVERY PRODUCT GRANTED A BEAUTIFUL COMPILATION TILE BADGE STAMP. ENJOY THE REFINED SENSATION OF CODES WELL DONE."
                        </p>
                        <div className="text-[9px] text-amber-600 font-black tracking-widest pt-1 border-t border-dashed border-yellow-300">
                          THANK YOU FOR SHOPPING WITH US! • POS TERMINAL COMPLIANCE
                        </div>
                      </motion.div>
                    )}

                    {/* Todo Cards matrix iterator */}
                    {todos.length > 0 ? (
                      <LayoutGroup>
                        <motion.div layout className="space-y-3.5">
                          {todos.map((todo, idx) => (
                            <TodoCard
                              key={todo.id}
                              todo={todo}
                              index={idx}
                              totalCount={todos.length}
                              isReadOnly={isSharedMode}
                              onToggleComplete={handleToggleComplete}
                              onDelete={handleDeleteTodo}
                              onUpdate={handleUpdateTodo}
                              onMoveUp={handleMoveUp}
                              onMoveDown={handleMoveDown}
                            />
                          ))}
                        </motion.div>
                      </LayoutGroup>
                    ) : (
                      !isEverythingChecked && (
                        <div className="bg-white border border-dashed border-slate-300 rounded-3xl p-12 text-center space-y-3">
                          <span className="text-4xl block animate-pulse">🧾</span>
                          <h4 className="text-xs font-extrabold text-slate-600 uppercase">NO REGISTERED MERCHANDISE</h4>
                          <p className="text-[10px] text-slate-400 max-w-xs mx-auto uppercase leading-relaxed">
                            Fill your daily billing card by registering goals inside the scanner form above! Let's start collecting.
                          </p>
                        </div>
                      )
                    )}
                  </div>
                </div>

                {/* Explanation manual / Checkout invoice feedback on right */}
                <div className="md:col-span-2 space-y-6">
                  
                  {/* Ledger Tutorial instructions card */}
                  <div className="bg-white p-5 rounded-2xl border-2 border-slate-800 shadow-sm space-y-3 text-[10px] text-slate-600 font-semibold uppercase leading-relaxed font-mono">
                    <h4 className="font-extrabold text-slate-800 flex items-center gap-1 pb-1.5 border-b border-dashed border-slate-200">
                      <BookOpen size={13} className="text-slate-700" />
                      COZY STATION PROTOCOLS (PDCA)
                    </h4>
                    <p className="font-bold">
                      A high-end receipt concept that powers focus into satisfying shopping rewards:
                    </p>
                    <ul className="space-y-2 list-none pl-1 text-[9.5px]">
                      <li className="flex items-start gap-1">
                        <strong className="text-slate-800">1. PLAN [商品-计划]:</strong>
                        <span>Scan custom task title as receipt products. Adjust details spec and colors.</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <strong className="text-slate-800">2. DO [打勾-执行]:</strong>
                        <span>Do focus blocks in Pomodoro tab, checkout values, and watch red stamp print!</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <strong className="text-slate-800">3. CHECK [收集-复盘]:</strong>
                        <span>Collect random dropped ceramic tile badges. Review logs on calendar.</span>
                      </li>
                    </ul>
                    <div className="pt-2 border-t border-dotted border-slate-300 text-[8.5px] text-slate-400 font-extrabold text-center">
                      — POS SYSTEM VERSION v4.1 —
                    </div>
                  </div>

                  {/* Active Selected day information reviews block */}
                  <div className="bg-white p-5 rounded-2xl border-2 border-slate-800 shadow-md space-y-3 font-mono text-[10px]">
                    <div className="flex items-center justify-between pb-2 border-b border-dashed border-slate-200">
                      <div className="flex items-center gap-1.5 text-slate-800 font-extrabold">
                        <Calendar size={13} />
                        <span>STATEMENT: {selectedDate}</span>
                      </div>
                      
                      <button
                        onClick={() => setShowReviewModal(true)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded font-bold transition-all cursor-pointer flex items-center gap-0.5 text-[9px] uppercase"
                      >
                        📝 Open Ledger
                      </button>
                    </div>

                    {/* Stat lists */}
                    {history[selectedDate] ? (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-[9px] text-slate-400 font-bold">
                          <span>CHECKED OUT ITEMS:</span>
                          <span className="font-extrabold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded">
                            {history[selectedDate]?.completedTodos?.length || 0} ITEMS
                          </span>
                        </div>

                        {/* List tiles of custom dates */}
                        {history[selectedDate]?.completedTodos && history[selectedDate].completedTodos.some(t => t.badgeSymbol) && (
                          <div className="bg-yellow-50/50 p-2 rounded border border-dashed border-yellow-200 flex flex-wrap gap-1 items-center">
                            <span className="font-extrabold text-amber-800 text-[8.5px]">TILES UNLOCKED:</span>
                            {history[selectedDate].completedTodos.map((todo, tIdx) => (
                              todo.badgeSymbol && (
                                <span key={tIdx} className="text-xs bg-white px-1.5 py-0.5 rounded border border-yellow-300 shadow-xs" title={todo.badgeName}>
                                  {todo.badgeSymbol}
                                </span>
                              )
                            ))}
                          </div>
                        )}

                        {history[selectedDate]?.dayNote ? (
                          <div className="p-3 bg-slate-50 rounded-xl border border-dotted border-slate-300 text-[9.5px] text-slate-600 leading-relaxed italic break-all whitespace-pre-wrap">
                            &ldquo; {history[selectedDate].dayNote} &rdquo;
                          </div>
                        ) : (
                          <div className="p-3 py-4 text-center bg-amber-50/30 rounded-xl border border-dashed border-amber-200 text-[9px] text-amber-800/60 font-bold uppercase">
                            No PDCA note logged. Click 'Open Ledger' to fill out daily recap summaries!
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-5 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-[9px] text-slate-400 font-bold uppercase">
                        {selectedDate === todayStr ? (
                          <p>Nothing Checked Out Today Yet. Start checking off objects! 🌻</p>
                        ) : (
                          <p>No historical transactions filed on this date receipt. 🌱</p>
                        )}
                      </div>
                    )}
                  </div>

                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3: RECEIPT CALENDAR ROLL (HEATMAP PAGE) */}
          {activeTab === 'calendar' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full relative z-0"
            >
              <Heatmap
                history={history}
                selectedDate={selectedDate}
                onSelectDate={(date) => {
                  setSelectedDate(date);
                  setShowReviewModal(true);
                }}
                todayCompletionsCount={todayCompletionsCount}
              />
            </motion.div>
          )}

        </section>

        {/* Quick access instructions badge for calendar selection */}
        {activeTab !== 'calendar' && (
          <div className="text-center">
            <button
              onClick={() => setActiveTab('calendar')}
              className="text-[9.5px] font-extrabold uppercase text-[#FF7EB3] hover:text-[#FF7EB3]/80 inline-flex items-center gap-1 cursor-pointer hover:underline"
            >
              📅 Quick check-in: Unfold bottom thermal calendar receipt roll to explore collected tile bonuses!
            </button>
          </div>
        )}

      </div>

      {/* PDCA Review entry modal */}
      <AnimatePresence>
        {showReviewModal && (
          <DailyReviewModal
            date={selectedDate}
            historyRecord={history[selectedDate]}
            onSaveNote={handleSaveDayNote}
            onClose={() => setShowReviewModal(false)}
          />
        )}
      </AnimatePresence>

      <footer className="text-center text-[10px] text-slate-400 mt-12 flex flex-col items-center justify-center gap-2 font-bold pb-8">
        <p className="flex items-center gap-1 uppercase">
          STATION OUTLET LOGS • Made with <Heart size={10} className="fill-rose-500 text-rose-500 animate-pulse" /> • SECURE CLIENT-SIDE TRANSACTION
        </p>
        <p className="text-[9px] text-slate-300 max-w-md uppercase tracking-wider leading-relaxed">
          © 2026 AESTHETIC SHOPPING TICKET CO. RECORDS ARE CONSERVED LOCAL TO DEV-DISK. PERSISTED LOCALLY COZILY.
        </p>
      </footer>
    </div>
  );
}
