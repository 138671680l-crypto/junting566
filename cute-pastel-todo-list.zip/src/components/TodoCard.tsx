/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronUp, ChevronDown, Trash2, Edit3, Save, Palette, AlignLeft, ShieldAlert } from 'lucide-react';
import { TodoItem } from '../types';

interface TodoCardProps {
  key?: React.Key;
  todo: TodoItem;
  index: number;
  totalCount: number;
  isReadOnly: boolean;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onUpdate: (id: string, updates: Partial<TodoItem>) => void;
  onMoveUp: (index: number) => void;
  onMoveDown: (index: number) => void;
}

// Pastel borders and accent styles for aesthetics
export const CAR_COLORS = [
  { id: 'pink', name: 'PINK FLOWER', border: 'border-pink-300', text: 'text-pink-600', bg: 'bg-pink-50/50' },
  { id: 'yellow', name: 'LEMON BANANA', border: 'border-yellow-300', text: 'text-amber-600', bg: 'bg-yellow-50/50' },
  { id: 'green', name: 'MINT TEA', border: 'border-emerald-300', text: 'text-emerald-700', bg: 'bg-emerald-50/50' },
  { id: 'purple', name: 'SWEET TARO', border: 'border-purple-300', text: 'text-purple-600', bg: 'bg-purple-50/50' },
  { id: 'blue', name: 'SEA WATER', border: 'border-sky-300', text: 'text-sky-600', bg: 'bg-sky-50/50' },
];

export default function TodoCard({
  todo,
  index,
  totalCount,
  isReadOnly,
  onToggleComplete,
  onDelete,
  onUpdate,
  onMoveUp,
  onMoveDown,
}: TodoCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(todo.title);
  const [editNote, setEditNote] = useState(todo.note || '');
  const [showColorPicker, setShowColorPicker] = useState(false);

  const matchedStyle = CAR_COLORS.find((c) => c.id === todo.color) || CAR_COLORS[0];

  const handleSave = () => {
    if (!editTitle.trim()) return;
    onUpdate(todo.id, {
      title: editTitle,
      note: editNote || undefined,
    });
    setIsEditing(false);
  };

  const handleColorSelect = (colorId: string) => {
    onUpdate(todo.id, { color: colorId });
    setShowColorPicker(false);
  };

  const serialNum = String(index + 1).padStart(3, '0');

  // Format the checkout time cleanly
  const checkTime = todo.completedAt 
    ? new Date(todo.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
    : '';

  return (
    <motion.div
      layoutId={`card-${todo.id}`}
      id={`todo-card-${todo.id}`}
      className={`relative p-5 bg-white border-2 border-dashed ${matchedStyle.border} shadow-sm transition-all duration-300 overflow-hidden group`}
      whileHover={{ y: -2, boxShadow: '0 8px 20px rgba(0,0,0,0.04)' }}
    >
      {/* Top Banner indicating read-only shared items */}
      {isReadOnly && (
        <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[9px] bg-amber-100 text-amber-700 font-mono font-bold tracking-wider uppercase flex items-center gap-1 z-10">
          <ShieldAlert size={10} /> SHARED READONLY
        </span>
      )}

      {/* Red PAID Stamp when completed */}
      <AnimatePresence>
        {todo.completed && (
          <motion.div
            initial={{ scale: 2.2, opacity: 0, rotate: -30 }}
            animate={{ scale: 1, opacity: 0.85, rotate: -12 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: 'spring', damping: 12, stiffness: 200 }}
            className="absolute top-4 right-16 z-20 pointer-events-none flex flex-col items-center justify-center border-4 border-double border-rose-500 bg-white/95 rounded-xl px-4 py-1 font-mono text-rose-500 font-extrabold shadow-md transform"
          >
            <span className="text-2xl tracking-widest uppercase select-none leading-none">PAID</span>
            <span className="text-[9px] tracking-normal font-mono text-rose-500 font-bold opacity-80 mt-0.5">
              {todo.completedAt || 'CHECKOUT'}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-start gap-4">
        {/* Adorable checkbox styled like a grocery basket check */}
        <button
          onClick={() => !isReadOnly && onToggleComplete(todo.id)}
          disabled={isReadOnly}
          className={`h-9 w-9 rounded-xl border-2 font-mono text-sm flex-shrink-0 transition-all flex items-center justify-center cursor-pointer disabled:cursor-not-allowed ${
            todo.completed 
              ? 'bg-rose-500 border-rose-500 text-white shadow-sm' 
              : 'border-slate-300 bg-white hover:border-rose-400 text-slate-400 hover:text-rose-500'
          }`}
          title={todo.completed ? "Mark as active" : "Check out item"}
        >
          {todo.completed ? (
            <motion.span 
              initial={{ scale: 0.4 }}
              animate={{ scale: 1 }}
              className="font-bold text-center"
            >
              ✔
            </motion.span>
          ) : (
            <span className="opacity-0 group-hover:opacity-100 text-[11px] font-bold">🛒</span>
          )}
        </button>

        {/* Content Area */}
        <div className="flex-1 min-w-0 font-mono text-xs">
          {isEditing ? (
            <div className="space-y-2 mt-1">
              <input
                type="text"
                className="w-full bg-slate-50 p-2.5 border-2 border-dashed border-slate-300 rounded-lg text-xs font-bold font-mono focus:outline-none focus:border-rose-400 text-slate-800"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="Product item name..."
              />
              <textarea
                className="w-full bg-slate-50 p-2.5 border-2 border-dashed border-slate-300 rounded-lg text-xs font-mono h-16 resize-none focus:outline-none focus:border-rose-400 text-slate-800"
                value={editNote}
                onChange={(e) => setEditNote(e.target.value)}
                placeholder="Item specification notes..."
              />
              <div className="flex items-center gap-1.5 pt-1">
                <button
                  onClick={handleSave}
                  className="px-3 py-1 bg-slate-800 text-white text-[10px] font-bold rounded hover:bg-slate-700 cursor-pointer"
                >
                  SAVE
                </button>
                <button
                  onClick={() => {
                    setEditTitle(todo.title);
                    setEditNote(todo.note || '');
                    setIsEditing(false);
                  }}
                  className="px-2.5 py-1 bg-slate-200 text-slate-700 text-[10px] font-bold rounded hover:bg-slate-300 cursor-pointer"
                >
                  CANCEL
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              {/* Product ID & Complete Stamp */}
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px]">
                <span>ITEM #{serialNum}</span>
                <span>•</span>
                <span>DEPT: GENERAL</span>
                {todo.completed && <span className="text-emerald-500 font-bold ml-1">✓ CHECKED</span>}
              </div>

              {/* Title display */}
              <h4
                className={`font-mono text-sm font-bold text-slate-800 leading-snug break-all ${
                  todo.completed ? 'line-through text-slate-400 decoration-rose-500/60 decoration-2' : ''
                }`}
              >
                {todo.title}
              </h4>

              {/* Specification Note Preview */}
              {todo.note && (
                <div className="bg-slate-50 p-2.5 border border-dashed border-slate-200 mt-2 rounded flex gap-1.5 items-start">
                  <AlignLeft size={12} className="text-slate-400 mt-0.5 shrink-0" />
                  <p className="text-[10px] text-slate-500 break-words whitespace-pre-wrap font-mono uppercase">
                    SPECIFICATION: {todo.note}
                  </p>
                </div>
              )}

              {/* Beautiful collected Badge display when completed */}
              {todo.completed && todo.badgeSymbol && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="inline-flex items-center gap-1.5 bg-yellow-50 border border-dashed border-yellow-300 text-amber-800 text-[10px] font-extrabold px-2.5 py-1 mt-2.5 rounded-full"
                >
                  <span className="text-xs">{todo.badgeSymbol}</span>
                  <span>BADGE BONUS: {todo.badgeName}</span>
                </motion.div>
              )}
            </div>
          )}
        </div>

        {/* Right operations */}
        {!isReadOnly && (
          <div className="flex items-center gap-1 shrink-0 ml-1">
            {/* Sorters */}
            <div className="flex flex-col gap-0.5">
              <button
                disabled={index === 0}
                onClick={() => onMoveUp(index)}
                className={`p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 disabled:opacity-20 transition-all cursor-pointer`}
                title="Move item up"
              >
                <ChevronUp size={14} />
              </button>
              <button
                disabled={index === totalCount - 1}
                onClick={() => onMoveDown(index)}
                className={`p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 disabled:opacity-20 transition-all cursor-pointer`}
                title="Move item down"
              >
                <ChevronDown size={14} />
              </button>
            </div>

            {/* Color Palette setting */}
            <div className="relative">
              <button
                onClick={() => setShowColorPicker(!showColorPicker)}
                className="p-1 text-slate-400 hover:text-rose-500 cursor-pointer"
                title="Change ticket color"
              >
                <Palette size={14} />
              </button>
              
              <AnimatePresence>
                {showColorPicker && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setShowColorPicker(false)} />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, y: 5 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 5 }}
                      className="absolute right-0 mt-1.5 z-40 bg-white p-2 rounded-lg border border-slate-200 shadow-xl w-32 space-y-1 font-mono text-[10px]"
                    >
                      {CAR_COLORS.map((color) => (
                        <button
                          key={color.id}
                          onClick={() => handleColorSelect(color.id)}
                          className={`w-full text-left px-2 py-1 rounded hover:bg-slate-50 flex items-center gap-1.5 font-bold cursor-pointer ${
                            todo.color === color.id ? 'bg-slate-50' : ''
                          }`}
                        >
                          <span
                            className={`w-3.5 h-3.5 rounded border border-slate-300 inline-block ${color.bg}`}
                          />
                          <span className={color.text}>{color.name}</span>
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Edit button */}
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="p-1 text-slate-400 hover:text-slate-800 cursor-pointer"
              title="Edit details"
            >
              <Edit3 size={14} />
            </button>

            {/* Delete button */}
            <button
              onClick={() => onDelete(todo.id)}
              className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
              title="Void item"
            >
              <Trash2 size={14} />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
