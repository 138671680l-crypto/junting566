/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Save, Sparkles, BookOpen, Star, ShieldAlert } from 'lucide-react';
import { DayHistoryRecord } from '../types';

interface DailyReviewModalProps {
  date: string;
  historyRecord: DayHistoryRecord | undefined;
  onSaveNote: (date: string, note: string) => void;
  onClose: () => void;
}

export default function DailyReviewModal({
  date,
  historyRecord,
  onSaveNote,
  onClose,
}: DailyReviewModalProps) {
  const [noteText, setNoteText] = useState('');

  useEffect(() => {
    if (historyRecord) {
      setNoteText(historyRecord.dayNote || '');
    } else {
      setNoteText('');
    }
  }, [historyRecord, date]);

  const handleSave = () => {
    onSaveNote(date, noteText);
  };

  const parsedDate = new Date(date);
  const weekDayStr = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][
    parsedDate.getDay()
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 15 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="w-full max-w-lg bg-white rounded-3xl border-4 border-slate-800 p-6 shadow-2xl relative overflow-hidden font-mono"
      >
        {/* Receipt aesthetic watermark design */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-bl-full pointer-events-none opacity-50 border-l border-b border-dashed border-slate-200" />

        {/* Modal Header */}
        <div className="flex justify-between items-start mb-5 relative">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-slate-100 text-slate-800 rounded-xl border border-slate-300">
              <BookOpen size={20} />
            </div>
            <div>
              <h2 className="text-sm font-extrabold tracking-tight text-slate-800 uppercase">
                REVIEW STATION / 复盘记
              </h2>
              <p className="text-[10px] text-slate-400 font-bold mt-0.5 font-mono">
                DATE: {date} ({weekDayStr})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="space-y-4 mb-6 relative z-10 text-xs">
          {/* Section: Completed items ledger */}
          <div className="bg-slate-50 p-4 rounded-xl border border-dashed border-slate-300">
            <h3 className="text-[10px] font-extrabold text-slate-700 uppercase mb-2 pb-1.5 border-b border-dashed border-slate-200 flex items-center justify-between">
              <span>CHECKED OUT ITEMS ({historyRecord?.completedTodos.length || 0})</span>
              <span className="text-rose-500 font-bold font-mono">★★★★★</span>
            </h3>
            
            {historyRecord && historyRecord.completedTodos.length > 0 ? (
              <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1 font-mono text-[10px] text-slate-600">
                {historyRecord.completedTodos.map((todo, idx) => (
                  <div
                    key={todo.id}
                    className="flex justify-between items-start py-0.5 border-b border-dotted border-slate-200"
                  >
                    <span className="font-bold truncate max-w-[280px]">
                      {idx + 1}. {todo.title}
                    </span>
                    <span className="text-slate-400 shrink-0 font-bold ml-2">
                      [PAID]
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10px] text-slate-400 italic py-2 text-center">
                 No items checked out on this receipt date. Run some tasks!
              </p>
            )}
          </div>

          {/* Section: Written Note reflection input */}
          <div className="space-y-1.5">
            <label className="block text-[10px] font-extrabold text-slate-700 uppercase flex items-center gap-1.5">
              <Star size={12} className="text-amber-500 fill-amber-500" />
              PDCA COUNTER / 今日反思与复盘
            </label>
            <textarea
              className="w-full h-28 p-3 bg-slate-50 rounded-xl border-2 border-dashed border-slate-300 focus:border-slate-800 focus:bg-white outline-none text-xs leading-relaxed text-slate-800 resize-none transition-all placeholder:text-slate-400"
              placeholder="What did you construct today? What was delayed? How can tomorrow's basket be improved? Write down your reflections here... 让每天都在闪闪发光。"
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
            />
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-dashed border-slate-200 text-[10px]">
          <span className="text-slate-400 font-bold font-mono">STATION #4910</span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 border border-slate-200 hover:border-slate-800 rounded font-bold transition-all cursor-pointer text-slate-500 uppercase"
            >
              Close
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-slate-800 text-white rounded font-bold hover:bg-slate-700 transition-all flex items-center gap-1 cursor-pointer uppercase shadow-md"
            >
              <span>Save Entry</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
