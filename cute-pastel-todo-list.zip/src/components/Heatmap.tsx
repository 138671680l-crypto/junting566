/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart, Flame, Calendar, Tag } from 'lucide-react';
import { generateHeatmapDays, formatDate } from '../utils/dateHelper';
import { CompletionHistory } from '../types';

interface HeatmapProps {
  history: CompletionHistory;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  todayCompletionsCount: number;
}

// 12 Monthly Theme Colors and Names
export const MONTHLY_THEMES: { [key: number]: { name: string; primary: string; text: string; bg: string; border: string } } = {
  0: { name: "JAN COLD FROST", primary: "#0284C7", text: "text-sky-700", bg: "bg-sky-50", border: "border-sky-200" }, // Jan
  1: { name: "FEB SWEET VALENTINE", primary: "#DB2777", text: "text-pink-600", bg: "bg-pink-50", border: "border-pink-200" }, // Feb
  2: { name: "MAR SPRING FOLIAGE", primary: "#059669", text: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200" }, // Mar
  3: { name: "APR CHERRY PEACH", primary: "#E11D48", text: "text-rose-600", bg: "bg-rose-50", border: "border-rose-200" }, // Apr
  4: { name: "MAY LEMON SUNSHINE", primary: "#D97706", text: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200" }, // May
  5: { name: "JUN SUMMER OCEAN", primary: "#0D9488", text: "text-teal-700", bg: "bg-teal-50", border: "border-teal-200" }, // Jun
  6: { name: "JUL SUNSET BEACH", primary: "#EA580C", text: "text-orange-600", bg: "bg-orange-50", border: "border-orange-200" }, // Jul
  7: { name: "AUG RetrO fields", primary: "#7C3AED", text: "text-violet-700", bg: "bg-violet-50", border: "border-violet-200" }, // Aug
  8: { name: "SEP GOLDEN HARVEST", primary: "#B45309", text: "text-yellow-700", bg: "bg-yellow-50", border: "border-yellow-200" }, // Sep
  9: { name: "OCT COZY GINGER", primary: "#C2410C", text: "text-amber-800", bg: "bg-amber-100/50", border: "border-amber-200" }, // Oct
  10: { name: "NOV WINTRY COCOA", primary: "#78350F", text: "text-amber-900", bg: "bg-orange-50", border: "border-amber-900/10" }, // Nov
  11: { name: "DEC CRIMSON HOLLY", primary: "#BE123C", text: "text-red-700", bg: "bg-red-50", border: "border-red-200" }, // Dec
};

export default function Heatmap({
  history,
  selectedDate,
  onSelectDate,
  todayCompletionsCount,
}: HeatmapProps) {
  // Generate list of 84 days context (12 weeks)
  const heatmapDays = generateHeatmapDays(new Date());
  
  // Group days into columns of 12 weeks
  const columns: Date[][] = [];
  for (let i = 0; i < 12; i++) {
    columns.push(heatmapDays.slice(i * 7, (i + 1) * 7));
  }

  const [hoveredDate, setHoveredDate] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);

  // Retrieve completions on a date
  const getDayCompletions = (dateStr: string) => {
    const todayStr = formatDate(new Date());
    if (dateStr === todayStr) {
      return todayCompletionsCount;
    }
    const record = history[dateStr];
    return record ? record.completedTodos.length : 0;
  };

  // Find the badge symbol of collected tile badges on a specific date (if any)
  const getDayBadge = (dateStr: string): string | null => {
    const record = history[dateStr];
    if (!record || !record.completedTodos) return null;
    
    // Find first completed todo that contains a badge symbol
    const found = record.completedTodos.find(t => t.badgeSymbol);
    return found ? found.badgeSymbol : null;
  };

  // Get active month based on the hovered date or selectedDate fallback
  const referenceDateStr = hoveredDate || selectedDate || formatDate(new Date());
  const referenceMonthIdx = new Date(referenceDateStr).getMonth();
  const theme = MONTHLY_THEMES[referenceMonthIdx] || MONTHLY_THEMES[5];

  const handleMouseEnter = (e: React.MouseEvent, dateStr: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const parent = e.currentTarget.parentElement?.parentElement?.getBoundingClientRect();
    if (parent) {
      setTooltipPosition({
        x: rect.left - parent.left + rect.width / 2,
        y: rect.top - parent.top - 10,
      });
    }
    setHoveredDate(dateStr);
  };

  const dayLabels = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

  // Total stat aggregations
  const totalCompleted = Object.values(history).reduce(
    (acc, cur) => acc + (cur.completedTodos?.length || 0),
    0
  ) + todayCompletionsCount;

  // Calculate Streak
  const getStreak = () => {
    let streakCount = 0;
    const today = new Date();
    for (let i = 0; i < 120; i++) {
      const walk = new Date();
      walk.setDate(today.getDate() - i);
      const walkStr = formatDate(walk);
      if (getDayCompletions(walkStr) > 0) {
        streakCount++;
      } else if (i === 0) {
        continue; // preserve today zero completion streak grace period
      } else {
        break;
      }
    }
    return streakCount;
  };

  const currentStreak = getStreak();

  return (
    <div className="bg-white p-6 rounded-3xl border-4 border-slate-800 shadow-md relative overflow-hidden font-mono receipt-jagged-bottom">
      
      {/* Decorative Receipt Header details */}
      <div className="text-center border-b-2 border-dashed border-slate-300 pb-5 mb-5 space-y-1 text-xs">
        <p className="tracking-widest font-black uppercase text-slate-800">
          ★★★ THERMAL CALENDAR AUDIT ★★★
        </p>
        <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold px-2 pt-1 font-mono">
          <span>TXN ID: #8809482</span>
          <span>REG: #05</span>
          <span>MONTHLY EDITION: {theme.name}</span>
        </div>
      </div>

      {/* Heatmap header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-700">
            <Calendar size={20} />
          </div>
          <div>
            <h3 className="font-mono font-extrabold text-sm text-slate-800 flex items-center gap-1">
              LEDGER MATRIX <Sparkles size={13} className="text-amber-500 animate-pulse" />
            </h3>
            <p className="text-[10px] text-slate-400 font-bold tracking-tight uppercase">
              Collected badges show directly on completed days!
            </p>
          </div>
        </div>

        {/* Dynamic Stats badges */}
        <div className="flex items-center gap-2 text-[10px] font-bold">
          <div className="bg-slate-50 border border-slate-300 px-2.5 py-1.5 rounded flex items-center gap-1 text-slate-700">
            <Heart size={11} className="fill-rose-500 text-rose-500" />
            CHECKOUTS: <span className="text-slate-900 font-extrabold">{totalCompleted}</span>
          </div>
          <div className="bg-amber-50 border border-amber-300 px-2.5 py-1.5 rounded flex items-center gap-1 text-amber-700">
            <Flame size={11} className="fill-amber-500 text-amber-500" />
            STREAK: <span className="text-amber-900 font-extrabold">{currentStreak} DAYS</span>
          </div>
        </div>
      </div>

      {/* Grid container with thermal paper theme background */}
      <div className="relative overflow-visible pb-1 select-none">
        
        {/* Dynamic Month Theme Header banner */}
        <div 
          className="px-3 py-1.5 rounded-lg border-2 border-dashed mb-4 flex justify-between items-center text-[10px] font-bold transition-all duration-300"
          style={{ borderColor: theme.primary, backgroundColor: `${theme.primary}08` }}
        >
          <span className="font-extrabold uppercase" style={{ color: theme.primary }}>
            🎨 ACTIVE EDITION: {theme.name}
          </span>
          <span className="font-mono opacity-80" style={{ color: theme.primary }}>
            THEME SELECTED
          </span>
        </div>

        <div className="flex overflow-x-auto py-2 scrollbar-none">
          {/* Day labels column */}
          <div className="grid grid-rows-7 gap-1.5 pr-3 text-[9px] font-extrabold text-slate-400 justify-items-center font-mono">
            {dayLabels.map((lbl, idx) => (
              <div key={idx} className="h-6 w-8 flex items-center justify-end">
                {lbl}
              </div>
            ))}
          </div>

          {/* Matrix roll */}
          <div className="flex gap-1.5 min-w-max relative overflow-visible flex-1 justify-between">
            {columns.map((columnDays, colIdx) => {
              const firstDayOfCol = columnDays[0];
              const isFirstOfColMonth = firstDayOfCol.getDate() <= 7;
              const colMonth = firstDayOfCol.getMonth();
              const monthLabelStr = isFirstOfColMonth
                ? ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'][colMonth]
                : '';

              return (
                <div key={colIdx} className="flex flex-col gap-1.5 relative">
                  {/* Month header labels on matrix */}
                  {monthLabelStr && (
                    <span 
                      className="absolute -top-5 left-0 text-[8px] font-extrabold tracking-widest whitespace-nowrap border-b border-dotted"
                      style={{ color: colMonth === referenceMonthIdx ? theme.primary : '#94A3B8', borderColor: colMonth === referenceMonthIdx ? theme.primary : '#E2E8F0' }}
                    >
                      {monthLabelStr}
                    </span>
                  )}
                  {columnDays.map((gameDay) => {
                    const dateStr = formatDate(gameDay);
                    const count = getDayCompletions(dateStr);
                    const badge = getDayBadge(dateStr);
                    const isSelected = selectedDate === dateStr;

                    // Compute styled BG classes based on state
                    let bgStyle = "bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-400";
                    if (count > 0) {
                      bgStyle = isSelected 
                        ? "bg-rose-50 border-2 border-rose-500 scale-110 z-10 text-rose-500"
                        : "bg-slate-100 border border-slate-300 text-slate-700 shadow-sm";
                    } else if (isSelected) {
                      bgStyle = "bg-rose-50/50 border-2 border-dashed border-rose-400 scale-110 z-10";
                    }

                    return (
                      <motion.button
                        key={dateStr}
                        id={`heatmap-cell-${dateStr}`}
                        whileHover={{ scale: 1.2, zIndex: 30 }}
                        onClick={() => onSelectDate(dateStr)}
                        onMouseEnter={(e) => handleMouseEnter(e, dateStr)}
                        onMouseLeave={() => setHoveredDate(null)}
                        className={`h-6.5 w-6.5 rounded-lg cursor-pointer transition-all duration-150 relative flex items-center justify-center text-[10px] ${bgStyle}`}
                      >
                        {/* Display badge bonus on completed day cells! */}
                        {badge ? (
                          <span className="text-xs filter drop-shadow-[0_1px_1px_rgba(0,0,0,0.1)] leading-none">
                            {badge}
                          </span>
                        ) : (
                          count > 0 && <span className="font-extrabold font-mono text-[9px]">✔</span>
                        )}

                        {/* Dot indicator if daily review exists */}
                        {history[dateStr]?.dayNote && (
                          <div className="absolute bottom-0.5 right-0.5 h-1 w-1 bg-amber-500 rounded-full" />
                        )}
                      </motion.button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Dynamic Micro Tooltip on Hover */}
        <AnimatePresence>
          {hoveredDate && tooltipPosition && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.12 }}
              style={{
                position: 'absolute',
                left: `${tooltipPosition.x}px`,
                top: `${tooltipPosition.y}px`,
                transform: 'translateX(-50%) translateY(-100%)',
              }}
              className="z-40 w-52 p-3 bg-white rounded-xl border-2 border-slate-800 shadow-xl text-[10px] text-slate-700 pointer-events-none font-mono"
            >
              <div className="font-extrabold text-slate-900 border-b border-dashed border-slate-200 pb-1.5 mb-1.5 flex justify-between items-center text-[10px] uppercase">
                <span>{hoveredDate}</span>
                <span className="font-mono text-[9.5px] text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                  {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'][new Date(hoveredDate).getDay()]}
                </span>
              </div>
              
              <div className="space-y-1 font-mono">
                <div className="flex justify-between items-center text-[9px] text-slate-500">
                  <span>ITEMS PURCHASED:</span>
                  <span className="font-extrabold text-slate-900">
                    {getDayCompletions(hoveredDate)} QTY
                  </span>
                </div>

                {/* Show the collected Badge on Hover Tooltip! */}
                {getDayBadge(hoveredDate) && (
                  <div className="bg-yellow-50 border border-dashed border-yellow-300 p-1.5 rounded flex items-center gap-1 mt-1 font-extrabold text-amber-800 text-[9px]">
                    <span className="text-xs">{getDayBadge(hoveredDate)}</span>
                    <span>BADGE: COLLECTED</span>
                  </div>
                )}

                {/* Listed Item checklist */}
                {history[hoveredDate] && (history[hoveredDate]?.completedTodos?.length || 0) > 0 && (
                  <div className="mt-1.5 pt-1.5 border-t border-dotted border-slate-200 text-slate-500 text-[8.5px] leading-tight">
                    <p className="font-extrabold text-slate-700 uppercase mb-1">RECEIPT ITEMS:</p>
                    <ul className="space-y-0.5 pl-1">
                      {history[hoveredDate].completedTodos.map((todo, tIdx) => (
                        <li key={tIdx} className="truncate flex items-center gap-1 uppercase">
                          <span className="text-rose-500">♥</span> {todo.title}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Review logs */}
                {history[hoveredDate]?.dayNote && (
                  <div className="mt-1.5 pt-1.5 border-t border-dashed border-slate-200 text-slate-500 text-[9px] leading-relaxed italic">
                    &ldquo;{history[hoveredDate].dayNote}&rdquo;
                  </div>
                )}
              </div>
              
              {/* Tooltip arrow */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-[8px] w-0 h-0 border-x-6 border-x-transparent border-t-6 border-t-white" />
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-[10px] w-0 h-0 border-x-6 border-x-transparent border-t-6 border-t-slate-800 -z-10" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Instructions Roll Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t-2 border-dashed border-slate-200 text-[9px] text-slate-400 font-bold uppercase font-mono">
        <span className="flex items-center gap-1">
          ✦ Click cell box to insert/edit PDCA logs!
        </span>
        <div className="flex items-center gap-1">
          <span>QTY:</span>
          <span>0</span>
          <div className="h-3 w-3 bg-slate-50 border border-slate-200" />
          <div className="h-3 w-3 bg-slate-100 border border-slate-300" />
          <div className="h-3 w-3 bg-rose-50 border border-rose-500" />
          <span>PAID</span>
        </div>
      </div>
    </div>
  );
}
