/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TodoItem {
  id: string;
  title: string;
  note?: string; // Daily reflection / task notes for Plan-Do-Check-Act (复盘)
  completed: boolean;
  completedAt?: string; // ISO date string YYYY-MM-DD
  createdAt: string; // ISO timestamp
  color: string; // Pastel pink, pastel yellow, etc.
  badgeSymbol?: string; // e.g. 🌸, 🌿, 🍋, 💜, 🍀, 🌼, 🍊, 🦋, 🍭, 🥨
  badgeName?: string; // e.g. ROSE CHERRY, MINT CLOVER, etc.
}

export interface DayHistoryRecord {
  date: string; // YYYY-MM-DD
  completedTodos: {
    id: string;
    title: string;
    note?: string;
    completedAt: string;
    badgeSymbol?: string;
    badgeName?: string;
  }[];
  dayNote?: string; // Overall daily reflection / review (复盘日记)
}

// Map of date string YYYY-MM-DD -> records
export interface CompletionHistory {
  [date: string]: DayHistoryRecord;
}

export interface ShareDataPayload {
  todos: TodoItem[];
  history: CompletionHistory;
}
